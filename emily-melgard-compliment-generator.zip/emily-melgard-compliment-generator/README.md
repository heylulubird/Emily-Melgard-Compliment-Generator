# Emily Melgard Compliment Generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/hey_lulubird/pen/qBzRZpB](https://codepen.io/hey_lulubird/pen/qBzRZpB).

